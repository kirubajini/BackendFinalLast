package com.User.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.User.model.User;
import com.User.service.UserService;

@CrossOrigin("*")
@RestController
@RequestMapping("/api/users")
public class UserController {
	@Autowired
	UserService userService;
	
	@GetMapping
	public ResponseEntity<List<User>> getAllUsers(){
		return userService.getAllUsers();
		
	}
	
	@GetMapping("/{id}")
	 public  ResponseEntity <User> getUserById(@PathVariable String id) {
	return userService.getUserById(id);
	}
	@PutMapping("/{id}")
	public ResponseEntity<User> updateUser(@RequestBody User user, @PathVariable String id) {
		System.out.println("updateUser_put");
	return userService.updateUser(id,user);

	}


	@DeleteMapping("/{id}")
	public ResponseEntity<User>  deleteUser(@PathVariable String id) {
	return userService.deleteUserById(id);
	}
	@GetMapping("/page")
	   public ResponseEntity<Map<String, Object>> getAllUserInPage(
	    @RequestParam(name = "pageNo", defaultValue = "0") int pageNo,
	    @RequestParam(name = "pageSize", defaultValue = "5") int pageSize,
	    @RequestParam(name = "sortBy", defaultValue = "id") String sortBy) {
	return userService.getAllUserInPage(pageNo, pageSize, sortBy);
	}
	
	@GetMapping(params="username")
	public ResponseEntity<List<User>> searchUser(@RequestParam String username){
		return userService.searchUser(username);
	}
	
	

}
